import requests

url = "http://localhost:8000/productos/"
nuevo_producto = {
    "nombre": "naranja",
    "precio": 10.50,
    "stock": 3
}

response = requests.post(url, json=nuevo_producto)
print("Respuesta del servidor:", response.json())
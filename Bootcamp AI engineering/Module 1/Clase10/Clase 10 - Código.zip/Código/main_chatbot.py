from fastapi import FastAPI
from pydantic import BaseModel
from langchain_core.prompts import ChatPromptTemplate
from langchain_openai import ChatOpenAI
from dotenv import load_dotenv
import os

# Cargar variables de entorno (API Key de OpenAI)
load_dotenv()

app = FastAPI()

# Modelo para recibir la pregunta del usuario
class Question(BaseModel):
    query: str

# Configurar LangChain
llm = ChatOpenAI(model="gpt-3.5-turbo", temperature=0.7)
prompt = ChatPromptTemplate.from_template("Responde de manera concisa: {input}")

# Endpoint para procesar preguntas
@app.post("/ask")
def ask_question(question: Question):
    chain = prompt | llm
    response = chain.invoke({"input": question.query})
    return {"answer": response.content}
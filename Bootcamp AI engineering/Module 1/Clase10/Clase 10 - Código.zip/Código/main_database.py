# pip install fastapi uvicorn supabase python-dotenv

from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
from supabase import create_client, Client
import os
from dotenv import load_dotenv

# Cargar variables de entorno
load_dotenv()

# Configuración de Supabase
SUPABASE_URL = os.getenv("SUPABASE_URL")
SERVICE_ROLE_KEY = os.getenv("SUPABASE_SERVICE_ROLE_KEY")

if not SUPABASE_URL or not SERVICE_ROLE_KEY:
    raise ValueError("Faltan credenciales de Supabase en las variables de entorno")

supabase: Client = create_client(SUPABASE_URL, SERVICE_ROLE_KEY)

app = FastAPI()


# Modelo Pydantic para usuarios
class UserCreate(BaseModel):
    name: str
    email: str


class UserUpdate(BaseModel):
    name: str


@app.post("/users/")
def create_user(user: UserCreate):
    """Crea un nuevo usuario en Supabase"""
    try:
        response = supabase.table("users").insert(user.dict()).execute()
        return response.data[0]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.put("/users/{email}")
def update_user(email: str, updates: UserUpdate):
    """Actualiza un usuario por email"""
    try:
        response = (
            supabase.table("users")
            .update(updates.dict())
            .eq("email", email)
            .execute()
        )
        if not response.data:
            raise HTTPException(status_code=404, detail="Usuario no encontrado")
        return response.data[0]
    except Exception as e:
        raise HTTPException(status_code=400, detail=str(e))


@app.get("/users/")
def get_users(email: str = None):
    """Obtiene todos los usuarios o filtra por email"""
    try:
        query = supabase.table("users").select("*")
        if email:
            query = query.eq("email", email)

        response = query.execute()
        return response.data
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=8000)